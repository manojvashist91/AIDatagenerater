<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'Data_Enabler' ) ) :

	/**
	 * Main Data_Enabler Class.
	 *
	 * @package		DATAENABLE
	 * @subpackage	Classes/Data_Enabler
	 * @since		1.0.0
	 * @author		Manoj Vashist
	 */
	final class Data_Enabler {

		/**
		 * The real instance
		 *
		 * @access	private
		 * @since	1.0.0
		 * @var		object|Data_Enabler
		 */
		private static $instance;

		/**
		 * DATAENABLE helpers object.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @var		object|Data_Enabler_Helpers
		 */
		public $helpers;

		/**
		 * DATAENABLE settings object.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @var		object|Data_Enabler_Settings
		 */
		public $settings;

		/**
		 * Throw error on object clone.
		 *
		 * Cloning instances of the class is forbidden.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @return	void
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, __( 'You are not allowed to clone this class.', 'data-enabler' ), '1.0.0' );
		}

		/**
		 * Disable unserializing of the class.
		 *
		 * @access	public
		 * @since	1.0.0
		 * @return	void
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, __( 'You are not allowed to unserialize this class.', 'data-enabler' ), '1.0.0' );
		}

		/**
		 * Main Data_Enabler Instance.
		 *
		 * Insures that only one instance of Data_Enabler exists in memory at any one
		 * time. Also prevents needing to define globals all over the place.
		 *
		 * @access		public
		 * @since		1.0.0
		 * @static
		 * @return		object|Data_Enabler	The one true Data_Enabler
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Data_Enabler ) ) {
				self::$instance					= new Data_Enabler;
				self::$instance->base_hooks();
				self::$instance->includes();
				self::$instance->helpers		= new Data_Enabler_Helpers();
				self::$instance->settings		= new Data_Enabler_Settings();

				//Fire the plugin logic
				new Data_Enabler_Run();

				/**
				 * Fire a custom action to allow dependencies
				 * after the successful plugin setup
				 */
				do_action( 'DATAENABLE/plugin_loaded' );
			}

			return self::$instance;
		}

		/**
		 * Include required files.
		 *
		 * @access  private
		 * @since   1.0.0
		 * @return  void
		 */
		private function includes() {
			require_once DATAENABLE_PLUGIN_DIR . 'core/includes/classes/class-data-enabler-helpers.php';
			require_once DATAENABLE_PLUGIN_DIR . 'core/includes/classes/class-data-enabler-settings.php';

			require_once DATAENABLE_PLUGIN_DIR . 'core/includes/classes/class-data-enabler-run.php';
		}

		/**
		 * Add base hooks for the core functionality
		 *
		 * @access  private
		 * @since   1.0.0
		 * @return  void
		 */
		private function base_hooks() {
			add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );
		}

		/**
		 * Loads the plugin language files.
		 *
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'data-enabler', FALSE, dirname( plugin_basename( DATAENABLE_PLUGIN_FILE ) ) . '/languages/' );
		}

	}

endif; // End if class_exists check.