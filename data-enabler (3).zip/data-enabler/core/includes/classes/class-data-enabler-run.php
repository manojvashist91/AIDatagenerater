<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Data_Enabler_Run
 *
 * Thats where we bring the plugin to life
 *
 * @package		DATAENABLE
 * @subpackage	Classes/Data_Enabler_Run
 * @author		Manoj Vashist
 * @since		1.0.0
 */
class Data_Enabler_Run{

	/**
	 * Our Data_Enabler_Run constructor 
	 * to run the plugin logic.
	 *
	 * @since 1.0.0
	 */
	function __construct(){
		$this->add_hooks();
	}

	/**
	 * ######################
	 * ###
	 * #### WORDPRESS HOOKS
	 * ###
	 * ######################
	 */

	/**
	 * Registers all WordPress and plugin related hooks
	 *
	 * @access	private
	 * @since	1.0.0
	 * @return	void
	 */
	private function add_hooks(){
		global $wpdb;
		require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
		add_action( 'plugin_action_links_' . DATAENABLE_PLUGIN_BASE, array( $this, 'add_plugin_action_link' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_backend_scripts_and_styles' ), 20 );
		add_action( 'admin_bar_menu', array( $this, 'add_admin_bar_menu_items' ), 100, 1 );
		add_action( 'admin_menu',array( $this, 'add_plugin_data_enable' ));

		$table_title= $wpdb->prefix."imported_title";
		$table_title2= $wpdb->prefix."exportes_title";
		// $sql = "DROP TABLE IF EXISTS $table_title";
    	// $wpdb->query($sql);

    	// $sql1 = "DROP TABLE IF EXISTS $table_title2";
    	// $wpdb->query($sql1);

		$sql1= "CREATE TABLE ".$table_title." ( `id` bigint(200) AUTO_INCREMENT, `title` varchar(255555) , `with_img` int(11) , `limit_text` varchar(255555), PRIMARY KEY (`id`))";
		$sql2= "CREATE TABLE ".$table_title2." ( `id` bigint(200) AUTO_INCREMENT,`sheetid` varchar(255555), `Wordof` varchar(255555), `Imageof` varchar(255555), `Abbreviationof` varchar(255555), `Descriptionof` varchar(255555), `Synonymsof` varchar(255555), `Variationsof` varchar(255555)  ,PRIMARY KEY (`id`))";
		dbDelta($sql1);
		dbDelta($sql2);
	}
		
	/**
	 * ######################
	 * ###
	 * #### WORDPRESS HOOK CALLBACKS
	 * ###
	 * ######################
	 */

	/**
	* Adds action links to the plugin list table
	*
	* @access	public
	* @since	1.0.0
	*
	* @param	array	$links An array of plugin action links.
	*
	* @return	array	An array of plugin action links.
	*/
	public function add_plugin_action_link( $links ) {

		$links['our_shop'] = sprintf( '<a href="%s" title="Custom Link" style="font-weight:700;">%s</a>', '', __( 'Custom Link', 'data-enabler' ) );

		return $links;
	}


	public function add_plugin_data_enable() {	
		add_menu_page('DATA ENABLE', 'DATA ENABLE', 'manage_options', 'DATAENABLE',
					array($this, 'Manojadd_plugin_data_enable_page'), plugins_url('/images/icon.png',  __FILE__ )); 
	}

	public	function Manojadd_plugin_data_enable_page() {
		require_once  'main_page.php';
	}



	/**
	 * Enqueue the backend related scripts and styles for this plugin.
	 * All of the added scripts andstyles will be available on every page within the backend.
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function enqueue_backend_scripts_and_styles() {
		wp_enqueue_script( 'dataenable-backend-scripts', DATAENABLE_PLUGIN_URL . 'core/includes/assets/js/backend-scripts.js', array(), DATAENABLE_VERSION, false );
		wp_localize_script( 'dataenable-backend-scripts', 'dataenable', array(
			'plugin_name'   	=> __( DATAENABLE_NAME, 'data-enabler' ),
		));
	}

	/**
	 * Add a new menu item to the WordPress topbar
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	object $admin_bar The WP_Admin_Bar object
	 *
	 * @return	void
	 */
	public function add_admin_bar_menu_items( $admin_bar ) {

		$admin_bar->add_menu( array(
			'id'		=> 'data-enabler-id', // The ID of the node.
			'title'		=> __( 'Demo Menu Item', 'data-enabler' ), // The text that will be visible in the Toolbar. Including html tags is allowed.
			'parent'	=> false, // The ID of the parent node.
			'href'		=> admin_url( 'admin.php?page=custom-page-slug' ), // The ‘href’ attribute for the link. If ‘href’ is not set the node will be a text node.
			'group'		=> false, // This will make the node a group (node) if set to ‘true’. Group nodes are not visible in the Toolbar, but nodes added to it are.
			'meta'		=> array(
				'title'		=> __( 'Demo Menu Item', 'data-enabler' ), // The title attribute. Will be set to the link or to a div containing a text node.
				'target'	=> '_blank', // The target attribute for the link. This will only be set if the ‘href’ argument is present.
				'class'		=> 'data-enabler-class', // The class attribute for the list item containing the link or text node.
				'html'		=> false, // The html used for the node.
				'rel'		=> false, // The rel attribute.
				'onclick'	=> false, // The onclick attribute for the link. This will only be set if the ‘href’ argument is present.
				'tabindex'	=> false, // The tabindex attribute. Will be set to the link or to a div containing a text node.
			),
		));

		$admin_bar->add_menu( array(
			'id'		=> 'data-enabler-sub-id',
			'title'		=> __( 'My sub menu title', 'data-enabler' ),
			'parent'	=> 'data-enabler-id',
			'href'		=> '#',
			'group'		=> false,
			'meta'		=> array(
				'title'		=> __( 'My sub menu title', 'data-enabler' ),
				'target'	=> '_blank',
				'class'		=> 'data-enabler-sub-class',
				'html'		=> false,    
				'rel'		=> false,
				'onclick'	=> false,
				'tabindex'	=> false,
			),
		));

	}

}
