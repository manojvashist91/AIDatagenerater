<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Data_Enabler_Helpers
 *
 * This class contains repetitive functions that
 * are used globally within the plugin.
 *
 * @package		DATAENABLE
 * @subpackage	Classes/Data_Enabler_Helpers
 * @author		Manoj Vashist
 * @since		1.0.0
 */
class Data_Enabler_Helpers{

	/**
	 * ######################
	 * ###
	 * #### CALLABLE FUNCTIONS
	 * ###
	 * ######################
	 */
	//$myvar = 'whatever';

	public function myplugin_activate() {
	
	  global $myvar;
	  echo $myvar; // this will NOT be 'whatever'!
	}
	
	//register_activation_hook( __FILE__, 'myplugin_activate' );
	
}
