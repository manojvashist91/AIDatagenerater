<header class="header-container">
	
</header>
<main class="text-center">
	<div class="card">
	<div class="form-wrapper">
		<form name="mss_form" id="mclick" method="POST" enctype="multipart/form-data" >
			<h2 style="padding: 10px;background: #2271b1;">Import</h2>
			<div class="csvfile_div fl_left">
				<input type="file" name="csv_file" id="csv_file" class="csv_file1" required/>
				 <input type="checkbox" name="with_img"  />&nbsp; With images
			</div>
			<br>
			Text Count Limit <input type="text" name="limit_text" value=""/>
			<br>
			<div class="submit_div fl_full">
				<?php 
				global $wpdb;
				$table_title= $wpdb->prefix."imported_title";	
				$result23 = $wpdb->get_results("SELECT * FROM ".$table_title."");
				// echo '<pre>';print_r($result23);die;
				?>
				<input type="submit" name="submit_title" value="Upload" class="upload_csv1" id="csv1" <?php if(isset($result23[0])) { echo 'disabled';} ?> >
			</div>
		</form>
		<h3 id="import_item"></h3>
	</div>
	</div>
</main>



<style>
	#loading {
	    width: 100%;
	    height: 100%;
	    top: 0px;
	    left: 0px;
	    position: fixed;
	    display: block;
	    opacity: 0.7;
	    background-color: #fff;
	    z-index: 99;
	    text-align: center;
	}

	#loading-image {
	    position: absolute;
	    top: 100px;
	    left: 240px;
	    z-index: 100;
	}
</style>


	<script>
		jQuery(document).ready(function(){
		 
			setInterval(function () {
				jQuery.ajax({
				    type: "post",
				    dataType: "json",
				    url: "<?php echo admin_url('admin-ajax.php'); ?>",
				    data: {
				        action:'check_data_import', //this value is first parameter of add_action
				        
				    },
				    success: function(msg){ 
				        if(msg.success == 'done'){
				        	var asss = jQuery('#main_export_con').find('#check_export_div').html();
							if(asss){
							    console.log('if');
							}else{
							    window.location.reload();
							}
				        	
				        }else if(msg.success == 'not'){
				        	jQuery('#import_item').empty();
				        }else{
				        	jQuery('#import_item').empty();
				        	jQuery('#csv1').prop('disabled', true);
				        	jQuery('#import_item').append('Total row imported -'+msg.import_item+' Please wait..');
				        	
				        }
				    }
				});
			}, 5000);
		});
	</script>
<?php

if(isset($_POST["submit_title"]))
{
	DE_import();
	
}
function DE_import(){
	if(isset($_POST["submit_title"])){
		if(isset($_FILES["csv_file"]["name"])){
			global $wpdb;
			$fileName=$_FILES["csv_file"]["name"];
			$fileSize=$_FILES["csv_file"]["size"]/1024;
			$fileType=$_FILES["csv_file"]["type"];
			$fileTmpName=$_FILES["csv_file"]["tmp_name"];
			$uploadPath= ABSPATH."/wp-content/uploads/".$fileName;

			$csv_types = array('text/csv','application/csv','text/comma-separated-values','application/excel','application/vnd.ms-excel','application/vnd.msexcel','text/anytext','application/octet-stream','application/txt');
			if(in_array($fileType, $csv_types ))
			{ 
				if(move_uploaded_file($fileTmpName,$uploadPath))
				{ 
					$table_title= $wpdb->prefix."imported_title";
					
					$de = array();
					$csv_file = $uploadPath;
					if (($handle = fopen($csv_file, "r")) !== FALSE) 
					{
						$count=0;
						$res=0;
						$my_key_array=array();
						$fp = file($csv_file);
						$row_total= count($fp);
						$title_arr = array();
						while (($data = fgetcsv($handle, 0, ',', '"')) !== FALSE)
						{
							if($count==0)
							{
								$my_key_array=$data;
								$res=0;
							}
							else
							{
								$num = count($data);
								for ($c=0; $c < $num; $c++) 
								{
									$de[$res][$my_key_array[$c]] = $data[$c];
								}

								$title_arr[] = $data[0];

							}
							if($count!=0){ $res++; }
							$width= ($count*100)/$row_total;
							?>
							<?php
							//echo'<script>document.getElementById("myBar").style.width = "'.$width.'px";</script>';
							$count++;
						}
					
						$show_json = json_encode($title_arr , JSON_FORCE_OBJECT);

							if ( json_last_error_msg()=="Malformed UTF-8 characters, possibly incorrectly encoded" ) {
								$show_json = json_encode($title_arr, JSON_PARTIAL_OUTPUT_ON_ERROR );
							}
							if ( $show_json !== false ) {
								$wpdb->insert(
									$table_title,
									array(
										'title'=>$show_json,
										'with_img'=>($_POST['with_img'])?1:0,
										'limit_text'=>$_POST['limit_text'],
									)
								);
							} else {
								die("json_encode fail: " . json_last_error_msg());
							}

					
						fclose($handle);
					}
					echo"<script>alert('Updated Successfully !');</script>";
					DE_export();
				}
			}
			else
			{
				echo"<script>alert('Please Import a valid CSV File !');</script>";
			}
		}else{
			echo"<script>alert('Please Import a valid CSV File !');</script>";
		}
	}
}
	// DE_export();
function DE_export() {
	global $wpdb;
	$table_title= $wpdb->prefix."imported_title";		
	$dex = array();
	$result = $wpdb->get_results("SELECT * FROM ".$table_title."");
	$result = json_decode($result[0]->title);
		if($result){
			foreach($result as $results){	
				$fts_mains = $results;
				$img = $results[0]->with_img; 
				  Send($results,$fts_mains,$img);
				"<br>";
			}
		}
}


ini_set('max_execution_time', 300);
function Send($fts,$fts_mains,$img) {
//$fts = 'acs';
	$aal_data = array();

  for($i=0;$i<6;$i++){
  	$main_url = '';
  	$p_data = '';
	  $fts = str_replace('"','',$fts);
	  $fts1 = '';
	  if($i==0){
		  $fts1 = "$fts"; 
		  $main_url = 'https://api.openai.com/v1/chat/completions';
		  $p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts1).'}]}';
	  }elseif($i==1){
		  $fts1 = '"Description of '.$fts.'"'; 
		  $main_url = 'https://api.openai.com/v1/chat/completions';
		  $p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts1).'}]}';
	  }elseif($i==2){
		  $fts1 = '"Synonyms of '.$fts.'"';
		  $main_url = 'https://api.openai.com/v1/chat/completions';
		  $p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts1).'}]}';
	  }elseif($i==3){
		  $fts1 = '"Variations of '.$fts.'"';
		  $main_url = 'https://api.openai.com/v1/chat/completions';
		  $p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts1).'}]}';
	  }elseif($i==4){
		  $fts1 = '"Abbreviation of '.$fts.'"'; 
		  $main_url = 'https://api.openai.com/v1/chat/completions';
		  $p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts1).'}]}';
	  }elseif($i==5){
		  $fts1 = '"Image of '.$fts.'"';
		  	if($img ==1){
			  $main_url = 'https://api.openai.com/v1/images/generations';
			  $p_data = '{"model":"dall-e-3","prompt": '.trim($fts1).',"n": 1,"size": "1024x1024"}';
			}else{
				$main_url = 'https://api.openai.com/v1/chat/completions';
		  		$p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts1).'}]}';
			}
		  
	  }
  
	 $curl = curl_init();
 
	 	curl_setopt_array($curl, array(
	   CURLOPT_URL => $main_url,
	   CURLOPT_RETURNTRANSFER => true,
	   CURLOPT_ENCODING => '',
	   CURLOPT_MAXREDIRS => 10,
	   CURLOPT_TIMEOUT => 0,
	   CURLOPT_FOLLOWLOCATION => true,
	   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	   CURLOPT_CUSTOMREQUEST => 'POST',
	   CURLOPT_POSTFIELDS =>($p_data),
	   CURLOPT_HTTPHEADER => array(
		 'Content-Type: application/json',
		 'Authorization: Bearer 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',
		 'Cookie: __cf_bm=Fo5JZHqOb97MiNOoX0616u4cPBCI6dv7ouxEs6Q3TZ8-1700478042-0-AfrFJbR6yXnxfsiyplvvemZp0Yzu+mmBAeYwRUf2LlKJ95rtrfo07GVEuthZbsScz+aJhg/Bm0IXhkPUFDGbR7w=; _cfuvid=aNE9BtyVd1zk0pg442f4nExJBL0CHvV_kNvuvhcE0bk-1700478042233-0-604800000'
	   ),
	 ));


 
	$response = curl_exec($curl);
	$response = json_decode($response, true);
	if($main_url =='https://api.openai.com/v1/images/generations'){
	 	if($response['data']){
	 		$re = $response['data'][0]['url'];
	 	}
	}
	if($main_url =='https://api.openai.com/v1/chat/completions'){
		 if($response['choices']){
		 	$re = $response['choices'][0]['message']['content'];
		 }
	}

	$ac  = trim($fts,'"');
	 $aal_data[] = @$re;
	 curl_close($curl);

	 }

	 global $wpdb;
	 $table_title2= $wpdb->prefix."exportes_title";
	 $count = $i;

	 $wpdb->insert(
		$table_title2,
		array(
			'sheetid'=>@$count,
			'Wordof'=>@$fts_mains,
			'Descriptionof'=>substr(@$aal_data[1], 0, 200),
			'Synonymsof'=>@$aal_data[2],
			'Variationsof'=>@$aal_data[3] ,
			'Abbreviationof'=>@$aal_data[4],
			'Imageof'=>@$aal_data[5],
		)
	);
	
}

if(isset($_POST["submit_title_ex"])){
	DE_export_csv($_POST["csv_file_de"]);

}


function array_to_csv_download($array, $filename = "csv_export.csv", $delimiter=";") {

	   global $wpdb;
	   $table_title2= $wpdb->prefix."imported_title";

	   $query1 = "SELECT * FROM $table_title2";
	   $result2 = $wpdb->get_results($query1);
	   $timit_text = $with_image ='';
	    if(isset($result2[0])){
		   $result234 = (array) $result2[0];
		   $timit_text = $result234['limit_text'];
		   $with_image = $result234['with_img'];
		}
	$filepath =  $filename.'.csv';
	ob_start();
	$output = fopen($filepath, 'w+');
 
	fputcsv($output, array("Id","Title","Excerpt", "Description", "Synonyms",'Variations',"Categories",'Abbreviation',"Tags",'Image',"Languages","_cmtt_highlightFirstOnly","_cmtt_disable_acf_for_page","_cmtt_new_page_exception","_cmttw_related_"));

	    foreach ($array as $results) { 
	    	if($timit_text){
	    		$decs = substr($results->Descriptionof, 0, $timit_text);
	    	}else{
	    		$decs = $results->Descriptionof;
	    	}
	    	if($with_image){
	    		$images = $results->Imageof;
	    	}else{
	    		$images = '';
	    	}
			fputcsv($output, array($results->id,$results->Wordof,'',trim(preg_replace('/\s+/', ' ', $decs)),trim(preg_replace('/\s+/', ' ', $results->Synonymsof)),trim(preg_replace('/\s+/', ' ', $results->Variationsof)),'',trim(preg_replace('/\s+/', ' ', $results->Abbreviationof)),'', trim(preg_replace('/\s+/', ' ', $images)),'',0,0,0,''));

	    }

	    
	@header('Content-Type: text/csv; charset=utf-8');
	@header('Content-Disposition: attachment; filename=csv_export.csv');
	
	// global $wpdb;
	// $table_title1 = $wpdb->prefix."imported_title";
	// $table_title2 = $wpdb->prefix."exportes_title";
	// 	   $wpdb->query("TRUNCATE TABLE $table_title1");
	// 	   $wpdb->query("TRUNCATE TABLE $table_title2");
	echo '<main class="text-center">
	<div class="card">
	<div class="form-wrapper"><form method="POST" id="download_form"><input type="hidden" value="download_form_post" name="download_form"/>';
	echo '<a href="'.$filepath.'" download="export" id="download_link">Download link</a>';
	echo '</form></div>
	</div>
	</main>';


} ?>

<?php 
	if(isset($_POST['download_form'])){ 
		global $wpdb;
	$table_title1 = $wpdb->prefix."imported_title";
	$table_title2 = $wpdb->prefix."exportes_title";
		   $wpdb->query("TRUNCATE TABLE $table_title1");
		   $wpdb->query("TRUNCATE TABLE $table_title2");
	}

	?>
<script>
	jQuery('#download_link').on('click',function(){console.log('ssdsds');
		jQuery('#download_form').submit();
	});
</script>
	
<?php
function DE_export_csv($t){
	if (isset($_POST["submit_title_ex"])) {
		$id = $_POST["csv_file_de"];

		   global $wpdb;
		   $table_title2= $wpdb->prefix."exportes_title";

		   $query = "SELECT * FROM $table_title2";
		   $result = $wpdb->get_results($query);
		   array_to_csv_download($result, $filename = "export.csv", $delimiter="") ;
		   
	   }
}
?>
<div id="main_export_con" >
	<?php
	 global $wpdb;
	 $table_title= $wpdb->prefix."exportes_title";	
	 $table_title1 = $wpdb->prefix."imported_title";	
	 $result1 = $wpdb->get_results("SELECT * FROM ".$table_title1."");	
	 $dex = array();
	 $result = $wpdb->get_results("SELECT * FROM ".$table_title."");
	 // echo '<pre>';print_r();die;
	 if($result && $result1){
	 	if(count( (array)json_decode($result1[0]->title)) == count($result)){
		 ?>
	 
		<main class="text-center" id="check_export_div">
		 <div class="card">
		 <div class="form-wrapper">
			 <form name="mss_formd" method="POST" enctype="multipart/form-data" >
				 <h2 style="padding: 10px;background: #2271b1;">Export</h2>
				 <div class="csvfile_div fl_left">
					 <input type="hidden" name="csv_file_de" value="1" class="csv_file1" required/>
				 </div>
				 <div class="submit_div fl_full">
					 <input type="submit" name="submit_title_ex" value="Export" class="upload_csv1">
				 </div>
			 </form>
		 </div>
		 </div>
		</main>

	<?php } }?>
	</div>