<header class="header-container">
	
</header>
<main class="text-center">
	<div class="card">
	<div class="form-wrapper">
		<form name="mss_form" method="POST" enctype="multipart/form-data" >
			<h2 style="padding: 10px;background: darkgray;">Import</h2>
			<div class="csvfile_div fl_left">
				<input type="file" name="csv_file" id="csv_file" class="csv_file1" required/>
			</div>
			<div class="fl_right">
				<div class="loader1" >
				</div>
			</div>
			<div class="submit_div fl_full">
				<input type="submit" name="submit_title" value="Upload" class="upload_csv1">
			</div>
		</form>
		<div class="fl_right">
		      <div id="loading">
               <img id="loading-image" src="http://cdn.nirmaltv.com/images/generatorphp-thumb.gif" alt="Loading..." />
              </div>
			</div>
	</div>
	</div>
</main>



<style>
	#loading {
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    position: fixed;
    display: block;
    opacity: 0.7;
    background-color: #fff;
    z-index: 99;
    text-align: center;
}

#loading-image {
    position: absolute;
    top: 100px;
    left: 240px;
    z-index: 100;
}
	</style>
	<script type="text/javascript">
		
				jQuery(document).ready(function(){
					jQuery('#loading').hide();
				jQuery('.upload_csv1').click(function(){
					jQuery('#loading').show();
					if(jQuery('.csv_file1').val()!="")
					{
						jQuery(window).load(function() {
							jQuery('#loading').hide();
				         });
					}
				});
				}); 
		</script>
<?php	
if(isset($_POST["submit_title"]))
{
	DE_import();
	
}
function DE_import()
    {
	if(isset($_POST["submit_title"]))
	{
		global $wpdb;
		$fileName=$_FILES["csv_file"]["name"];
		$fileSize=$_FILES["csv_file"]["size"]/1024;
		$fileType=$_FILES["csv_file"]["type"];
		$fileTmpName=$_FILES["csv_file"]["tmp_name"];
		$uploadPath= ABSPATH."/wp-content/uploads/".$fileName;

		$csv_types = array('text/csv','application/csv','text/comma-separated-values','application/excel','application/vnd.ms-excel','application/vnd.msexcel','text/anytext','application/octet-stream','application/txt');
		if(in_array($fileType, $csv_types ))
		{ 
			?>
			<script type="text/javascript">
				jQuery('#myProgress').show();
			</script>
			<?php
			if(move_uploaded_file($fileTmpName,$uploadPath))
			{ 
				$table_title= $wpdb->prefix."imported_title";
				
				$de = array();
				$csv_file = $uploadPath;
				if (($handle = fopen($csv_file, "r")) !== FALSE) 
				{
					$count=0;
					$res=0;
					$my_key_array=array();
					$fp = file($csv_file);
					$row_total= count($fp);
					$title_arr = array();
					while (($data = fgetcsv($handle, 0, ',', '"')) !== FALSE)
					{
						if($count==0)
						{
							$my_key_array=$data;
							$res=0;
						}
						else
						{
							$num = count($data);
							for ($c=0; $c < $num; $c++) 
							{
								$de[$res][$my_key_array[$c]] = $data[$c];
							}

							$title_arr[] = $data[0];

							/***********Inserting value into Catalog Table Table Start*****************/
						
							/***********Inserting value into MSS Table End *****************/

						}
						if($count!=0){ $res++; }
						$width= ($count*100)/$row_total;
						?>
						<?php
						//echo'<script>document.getElementById("myBar").style.width = "'.$width.'px";</script>';
						$count++;
					}
				
					$show_json = json_encode($title_arr , JSON_FORCE_OBJECT);
						if ( json_last_error_msg()=="Malformed UTF-8 characters, possibly incorrectly encoded" ) {
							$show_json = json_encode($title_arr, JSON_PARTIAL_OUTPUT_ON_ERROR );
						}
						if ( $show_json !== false ) {
							$wpdb->insert(
								$table_title,
								array(
									'title'=>$show_json,
								)
							);
						} else {
							die("json_encode fail: " . json_last_error_msg());
						}

				
					fclose($handle);
				}
				echo"<script>alert('Updated Successfully !');</script>";
				DE_export();
			}
		}
		else
		{
			echo"<script>alert('Please Import a valid CSV File !');</script>";
		}
	}
    }

	//DE_export();


	 function DE_export() {
		global $wpdb;
		$table_title= $wpdb->prefix."imported_title";		
		$dex = array();
	    $result = $wpdb->get_results("SELECT * FROM ".$table_title."");
        //print_r($result);
		
		foreach($result as $results){

			$results_t = str_replace("[", "",$results->title);
			$results_t =  str_replace("]", "",$results_t);
			$ft = explode(',',$results_t);
			foreach($ft as $fts){	
				  Send($fts);
				"<br>";
			}
		}
	 }
	 ini_set('max_execution_time', 300);
	 function Send($fts) {
		//$fts = 'acs';
		$aal_data = array();
		
		  for($i=0;$i<6;$i++){
		  $fts = str_replace('"','',$fts);
		  if($i==0){
			  $fts = "$fts";
		  }elseif($i==1){
			  $fts = '"Description of '.$fts.'"';
		  }elseif($i==2){
			  $fts = '"Synonyms of '.$fts.'"';
		  }elseif($i==3){
			  $fts = '"Variations of '.$fts.'"';
		  }elseif($i==4){
			  $fts = '"Abbreviation of '.$fts.'"';
		  }elseif($i==5){
			  $fts = '"Image of '.$fts.'"';
		  }
		 $curl = curl_init();
 
		 $p_data = '{"model":"gpt-3.5-turbo","messages":[{"role":"user","content":'.trim($fts).'}]}';
		 // echo '<pre>';print_r($p_data);//die;
		 curl_setopt_array($curl, array(
		   CURLOPT_URL => 'https://api.openai.com/v1/chat/completions',
		   CURLOPT_RETURNTRANSFER => true,
		   CURLOPT_ENCODING => '',
		   CURLOPT_MAXREDIRS => 10,
		   CURLOPT_TIMEOUT => 0,
		   CURLOPT_FOLLOWLOCATION => true,
		   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		   CURLOPT_CUSTOMREQUEST => 'POST',
		   CURLOPT_POSTFIELDS =>($p_data),
		   CURLOPT_HTTPHEADER => array(
			 'Content-Type: application/json',
			 'Authorization: Bearer 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',
			 'Cookie: __cf_bm=Fo5JZHqOb97MiNOoX0616u4cPBCI6dv7ouxEs6Q3TZ8-1700478042-0-AfrFJbR6yXnxfsiyplvvemZp0Yzu+mmBAeYwRUf2LlKJ95rtrfo07GVEuthZbsScz+aJhg/Bm0IXhkPUFDGbR7w=; _cfuvid=aNE9BtyVd1zk0pg442f4nExJBL0CHvV_kNvuvhcE0bk-1700478042233-0-604800000'
		   ),
		 ));
 
 
		 
		 $response = curl_exec($curl);
		 $response = explode(':',$response);
		 if (array_key_exists("9",$response)){
			$re1 = str_replace('"finish_reason"','',$response[9]);
			$re = str_replace('},','',$re1);
		 }
		 $aal_data[$fts] = @$re;
		 curl_close($curl);
		 
		 }
		 global $wpdb;
		 $table_title2= $wpdb->prefix."exportes_title";
         $count = 1;
		 foreach($aal_data as $key=>$value){
		 $wpdb->insert(
			$table_title2,
			array(
				'sheetid'=>$count,
				'Wordof'=>$key,
				'Descriptionof'=>$value,
				'Synonymsof'=>$value,
				'Variationsof'=>$value,
				'Abbreviationof'=>$value,
				'Imageof'=>$value,
			)
		);
		$count++;
	    } 
	 }



	 if(isset($_POST["submit_title_ex"]))
{
	DE_export_csv($_POST["csv_file_de"]);
	
}


function array_to_csv_download($array, $filename = "export.csv", $delimiter=";") {



	$filename = 'testmanoj';

$filepath =  $filename.'.csv';
$output = fopen($filepath, 'w+');

//fputcsv($output, array('Word of','Descriptionof','Synonymsof','Variationsof','Abbreviationof', 'Imageof')); 
fputcsv($output, array("Word", "Description", "Synonyms of",'Variations of','Abbreviation of','Image of'));

    foreach ($array as $results) { 
        // generate csv lines from the inner arrays
		fputcsv($output, array($results->Wordof,$results->Descriptionof,$results->Synonymsof,$results->Variationsof,$results->Abbreviationof, $results->Imageof));

    }
//fputcsv($output, array("Number", "Description", "test"));
//fputcsv($output, array("100", "testDescription", "10"));

@header('Content-Type: application/octet-stream');
@header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
@header('Content-Length: ' . filesize($filepath)); 
//echo readfile($filepath);
echo '<main class="text-center">
<div class="card">
<div class="form-wrapper">';
echo '<a href="'.$filepath.'" download="export">Download link</a>';
echo '</div>
</div>
</main>';
}


function DE_export_csv($t){
	if (isset($_POST["submit_title_ex"])) {
		$id = $_POST["csv_file_de"];

		   global $wpdb;
		   $table_title2= $wpdb->prefix."exportes_title";

		   $query = "SELECT * FROM $table_title2";
		   $result = $wpdb->get_results($query);
		   array_to_csv_download($result, $filename = "export.csv", $delimiter=";") ;
	   }
}
	 global $wpdb;
	 $table_title= $wpdb->prefix."imported_title";		
	 $dex = array();
	 $result = $wpdb->get_results("SELECT * FROM ".$table_title."");
	 //print_r($result);
	 foreach($result as $results){
		 ?>
<main class="text-center">
 <div class="card">
 <div class="form-wrapper">
	 <form name="mss_formd" method="POST" enctype="multipart/form-data" >
		 <h2 style="padding: 10px;background: darkgray;">Export</h2>
		 <div class="csvfile_div fl_left">
			 <input type="hidden" name="csv_file_de" value="<?php echo $results->id; ?>" class="csv_file1" required/>
		 </div>
		 <!-- <div class="fl_right">
			 <div class="loader12" >
			 </div>
		 </div> -->
		 <div class="submit_div fl_full">
			 <input type="submit" name="submit_title_ex" value="Export" class="upload_csv1">
		 </div>
	 </form>
	 <!-- <div class="fl_right">
		   <div id="loading">
			<img id="loading-image" src="http://cdn.nirmaltv.com/images/generatorphp-thumb.gif" alt="Loading..." />
		   </div>
		 </div> -->
 </div>
 </div>
</main>

<?php
	 }