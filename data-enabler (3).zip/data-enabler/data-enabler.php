<?php
/**
 * Data Enabler
 *
 * @package       DATAENABLE
 * @author        xyz
 * @license       gplv2
 * @version       1.0.0
 *
 * @wordpress-plugin
 * Plugin Name:   Data Enabler
 * Plugin URI:    xyz
 * Description:   Data Enabler
 * Version:       1.0.0
 * Author:        xyz
 * Author URI:    #
 * Text Domain:   data-enabler
 * Domain Path:   /languages
 * License:       GPLv2
 * License URI:   https://www.gnu.org/licenses/gpl-2.0.html
 *
 * You should have received a copy of the GNU General Public License
 * along with Data Enabler. If not, see <https://www.gnu.org/licenses/gpl-2.0.html/>.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;
// Plugin name
define( 'DATAENABLE_NAME',			'Data Enabler' );

// Plugin version
define( 'DATAENABLE_VERSION',		'1.0.0' );

// Plugin Root File
define( 'DATAENABLE_PLUGIN_FILE',	__FILE__ );

// Plugin base
define( 'DATAENABLE_PLUGIN_BASE',	plugin_basename( DATAENABLE_PLUGIN_FILE ) );

// Plugin Folder Path
define( 'DATAENABLE_PLUGIN_DIR',	plugin_dir_path( DATAENABLE_PLUGIN_FILE ) );

// Plugin Folder URL
define( 'DATAENABLE_PLUGIN_URL',	plugin_dir_url( DATAENABLE_PLUGIN_FILE ) );

/**
 * Load the main class for the core functionality
 */
require_once DATAENABLE_PLUGIN_DIR . 'core/class-data-enabler.php';

/**
 * The main function to load the only instance
 * of our master class.
 *
 * @author  Manoj Vashist
 * @since   1.0.0
 * @return  object|Data_Enabler
 */
function DATAENABLE() {
	return Data_Enabler::instance();
}

DATAENABLE();


add_action( 'wp_ajax_nopriv_check_data_import', 'check_data_import' );
add_action( 'wp_ajax_check_data_import', 'check_data_import' );


function check_data_import(){
	 global $wpdb;
	 $table_title= $wpdb->prefix."exportes_title";	
	 $table_title1 = $wpdb->prefix."imported_title";	
	 $result1 = $wpdb->get_results("SELECT * FROM ".$table_title1."");	
	 $dex = array();
	 $result = $wpdb->get_results("SELECT * FROM ".$table_title."");
	 $cbd = (array)json_decode($result1[0]->title);
	 if($result || $result1){
		 if(count($cbd) == count($result)){
		 	$ar = ['success'=>'done'];
		 	echo json_encode($ar);
		 }else{
		 	echo json_encode(['success'=>'failed','import_item'=>count($result)]);
		 }
	}else{
		echo json_encode(['success'=>'not']);
	}
	exit();

}


/**
 * Register the "book" custom post type
 */
function pluginprefix_setup_post_type() {
	add_option( 'Activated_Plugin', 'Plugin-datatable' );
} 
add_action( 'init', 'pluginprefix_setup_post_type' );


/**
 * Activate the plugin.
 */
function pluginprefix_activate() { 
	flush_rewrite_rules(); 
}
register_activation_hook( __FILE__, 'pluginprefix_activate' );


/**
 * Deactivation hook.
 */
function pluginprefix_deactivate() {
	
	delete_option( 'Activated_Plugin');

	global $wpdb;
	$table_title= $wpdb->prefix."imported_title";
	$table_title2= $wpdb->prefix."exportes_title";
	 $sql = "DROP TABLE IF EXISTS $table_title";
	 $wpdb->query($sql);

	 $sql1 = "DROP TABLE IF EXISTS $table_title2";
	 $wpdb->query($sql1);
	 
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'pluginprefix_deactivate' );